import React from 'react';

const Content = () => {
  return (
    <div className="content">
      <div className="content-l">
        <div className="content-left__header">
          <div className="content-left__table-nr">
            Borð nr:
          </div>
          <div className="content-left__order-nr">
            Pöntun:
          </div>
          <div className="content-left__order-status">
            Staða á pöntun:
          </div>

        </div>
      </div>
      <div className="content__right">

      </div>
    </div>

  )
};
export default Content;
