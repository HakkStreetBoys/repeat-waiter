import firebase from 'firebase';

firebase.initializeApp({
  apiKey: "AIzaSyBqxVu2HGo992cGCb0UUPbl4cvh_FVFgbo",
  authDomain: "one-time-password-c0c13.firebaseapp.com",
  databaseURL: "https://one-time-password-c0c13.firebaseio.com",
  projectId: "one-time-password-c0c13",
  storageBucket: "one-time-password-c0c13.appspot.com",
  messagingSenderId: "224931022962"
});

export default firebase;
