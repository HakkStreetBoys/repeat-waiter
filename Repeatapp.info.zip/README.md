# ReduxSimpleStarter

Interested in learning [Redux](https://www.udemy.com/react-redux/)?

####Not Familiar with Git?#####
Click [here](https://github.com/StephenGrider/ReactStarter/releases) then download the .zip file.  Extract the contents of the zip file, then open your terminal, change to the project directory, and:

```
	> npm install
	> npm start
```
